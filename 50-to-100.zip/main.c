#include <stdio.h>

int main() {
    int i;

    for (i = 50; i <= 100; i++) {
        printf("%d ", i);
    }

    return 0;
}

