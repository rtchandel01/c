/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int phy,chem,bio,cs;
    char pass;
    printf("enter the value of phy, chem, bio, cs");
    scanf("%d %d %d %d" ,&phy ,&chem ,&bio ,&cs);
    
    if(phy>=40&&chem>=40&&bio>=40&&cs>=40)
    {
        int sum = phy + chem + bio + cs;
    float avg = (float)sum / 4;
    printf("Average marks: %f", avg);
    
        printf("pass");
        
    }
    else
    {
        printf("fail");
    }

    return 0;
}

