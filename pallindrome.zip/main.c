#include<stdio.h>
int main()
{
    int a;
    printf("enter the number - ");
    scanf("%d" ,&a);
    int temp,rem,sum=0;
    temp=a;
    while(a>0)
    {
        rem=a%10;
        sum=sum*10+rem;
        a=a/10;
    }
    if(temp == sum)
    {
        printf("this is pallindrome");
    }
    else
    {
         printf("this is not a pallindrome");
    }

}
