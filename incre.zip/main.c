#include<stdio.h>
int main()
{
    int a=5;
    while(a>=1)
    {
        printf("%d\n" ,a);
        a--;
    }
    return 0;
}