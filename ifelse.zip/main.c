#include<stdio.h>
int main()
{
    int num;
    printf("enter the number");
    scanf("%d" ,&num);
    if(num>50)
    {
        printf("no. is greater then 50");
        
    }
    else
    {
        printf("no. is less then 50");
    }
    return 0;
}