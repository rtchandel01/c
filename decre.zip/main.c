#include<stdio.h>
int main()
{
    int a=10;
    while(a>=1)
    {
        printf("%d\n" ,a);
        a--;
    }
    return 0;
}