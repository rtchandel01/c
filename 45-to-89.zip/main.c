#include <stdio.h>

int main() {
    int i;

    for (i = 45; i <= 89; i++) {
        printf("%d ", i);
    }

    return 0;
}
