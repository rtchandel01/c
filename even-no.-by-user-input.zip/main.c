#include <stdio.h>

int main() {
    int a, b;

    printf("Enter the starting number: ");
    scanf("%d", &a);

    printf("Enter the ending number: ");
    scanf("%d", &b);

    if (a % 2 != 0) {
        a++;
    }

    while (a <= b) {
        printf("%d ", a);
        a+= 2;
    }

    return 0;
}

