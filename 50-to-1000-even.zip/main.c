#include <stdio.h>

int main() {
    for (int i = 50; i <= 1000; i += 2) {
        printf("%d ", i);
    }

    return 0;
}
