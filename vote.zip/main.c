#include<stdio.h>
int main()
{
    int age;
    printf("enter your age");
    scanf("%d" ,&age);
    if
    (age>=18)
    { printf("you are valid for vote");
    
    }
else{
    printf("you are not valid for vote");
}
    return 0;
}