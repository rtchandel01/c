/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    char t;
    char a,e,i,o,u;
    printf("enter alphabet");
    scanf("%c" ,&t);
    if(t=='a'||t=='e'||t=='i'||t=='o'||t=='u')
    {
        printf("this is a vowel");
    }
    else{
        printf("this is a consonant");
    }

    return 0;
}
