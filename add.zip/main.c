#include<stdio.h>
int main()
{
  int a=6, b=3;
  
  printf("enter the no.of a= ");
  scanf("%d" ,&a);
  printf("enter the no.of b= ");
  scanf("%d" ,&b);
  int result=a+b;
  printf("%d" ,result);
  
    return 0;
}