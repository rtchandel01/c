/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main() 
{
    char tc;

    printf("enter a character:- ");
    scanf("%c", &tc);

    if ((tc >= 'a' && tc <= 'z') || (tc >= 'A' && tc <= 'Z')) 
	 {
        printf("it is an alphabet.\n");
    } else {
        printf("it is not an alphabet.\n");
    }

    return 0;
}