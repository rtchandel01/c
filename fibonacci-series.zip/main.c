#include <stdio.h>

int main() {
    int n, a=0 ,b=1 ,c ,i;
    
    printf("Enter the number of terms in the Fibonacci series: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
  printf("%d ", a);
   c=a+b;
   a=b;
   b=c;
    }

    printf("\n");

    return 0;
}
