/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
 int hindi, maths, science ,cs ,english;
 printf("enter the value for hindi, english, maths ,science, cs");
 scanf("%d %d %d %d %d" ,&hindi ,&english ,&maths ,&science ,&cs);
 if(hindi>=40&&english>=40&&maths>=40&&science>=40&&cs>=40)
 {
     printf("you are passed");
     
 }
else
{
   printf("you are failed"); 
}
    return 0;
}
